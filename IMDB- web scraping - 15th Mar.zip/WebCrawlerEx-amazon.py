import requests  #default 
from bs4 import BeautifulSoup #you need to install bs4


res = requests.get("https://www.amazon.com/Apple-iPhone-Silver-Locked-Prepaid/dp/B076MP43X5/ref=sr_1_1?keywords=iphone&qid=1584249431&sr=8-1")
#print(res.url)


out = BeautifulSoup(res.text,"html.parser")

print(out.prettify())

#out.findAll('a-section a-spacing-medium')
#print(out)

#div = out.find_all("div", {"class": "a-section a-spacing-medium"})
#div = out.find_all('div')

div = out.find_all('div')

print(len(div))
print(div[0])
#print(div[1])
#print(div[2])


#a-section a-spacing-medium








