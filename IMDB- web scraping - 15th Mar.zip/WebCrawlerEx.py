import requests


res = requests.get("https://yahoo.com")

print(res)
print(res.status_code)
print(res.url)  
print(res.text)


'''
code
200: ok
400: server is not responding
404:  page is not found

'''



