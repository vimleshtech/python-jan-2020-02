Python 3.7.7 (tags/v3.7.7:d7c567b08f, Mar 10 2020, 10:41:24) [MSC v.1900 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import tweepy
>>> 
= RESTART: C:/Users/vkumar15/AppData/Local/Programs/Python/Python37/TweetExample.py
etner leader name:Narendra Modi
Traceback (most recent call last):
  File "C:/Users/vkumar15/AppData/Local/Programs/Python/Python37/TweetExample.py", line 24, in <module>
    res = api.serach(q=name,count=10) # q = find tweet for, count =no of tweet
AttributeError: 'API' object has no attribute 'serach'
>>> 
= RESTART: C:/Users/vkumar15/AppData/Local/Programs/Python/Python37/TweetExample.py
etner leader name:Narendra Modi










>>> 
= RESTART: C:/Users/vkumar15/AppData/Local/Programs/Python/Python37/TweetExample.py
etner leader name:Narendra Modi
RT @ZeeNewsHindi: केविन पीटरसन ने देसी अंदाज में किया था ये ट्वीट...

#Corona #CoronaVirus #CoronaVirusUpdate #ZeeJankariOnCorona @narendra…
RT @livemint: #CoronavirusOutbreak: PM Modi said the threat of the pandemic is common for all states 

https://t.co/GIPVQ6m3PE
RT @thewire_in: "The idea of a ‘janata curfew’ is welcome, but it puts the entire onus on the individual. 

What, one is entitled to ask, i…
RT @ZeeNewsHindi: केविन पीटरसन ने देसी अंदाज में किया था ये ट्वीट...

#Corona #CoronaVirus #CoronaVirusUpdate #ZeeJankariOnCorona @narendra…
RT @narendramodi: Today, via video conferencing, had an extensive interaction with Chief Ministers of various states to discuss ongoing eff…
RT @sumitkashyapjha: Has anyone seen

PM Narendra Modi
HM Amit Shah
DM Rajnath Singh

in public in this week?

Have you seen
FM Nirmala Shi…
RT @RTforINDIA: प्रिय @PMOIndia 
आपको एक पैकेज की घोषणा करनी चाहिए अगर पैकेज नहीं दे रहे हैं तो कम से कम देश के नागरिकों की नौकरियां तो बचा…
RT @narendramodi: Today, via video conferencing, had an extensive interaction with Chief Ministers of various states to discuss ongoing eff…
Jiwan Books and Edu Hub Publishing Company stand with our Honorable PM Shri Narendra Modi ji  and each and every me… https://t.co/ZwquNoRgME
RT @narendramodi: Today, via video conferencing, had an extensive interaction with Chief Ministers of various states to discuss ongoing eff…
>>> 
= RESTART: C:/Users/vkumar15/AppData/Local/Programs/Python/Python37/TweetExample.py
etner leader name:Rahul Gandhi
-----------tweet for Rahul Gandhi ------------
RT @AadeshRawal: जब निर्भय के भाई को राहुल गांधी ने अमेठी के इंदिरा गांधी उड़ान अकादमी में दाख़िला दिलवाया था तो मेरे एक सूत्र में मुझे बता…
@tehseenp @PMOIndia @narendramodi Bhai plz ek baar Rahul &amp; Robert Priyanka ke sath Italy ja ke Nani se mil aayo tab… https://t.co/oe9bjF3B3o
RT @Aaabshar: BJP MP who has commented on Sonia Gandhi and Rahul Gandhi being from Italy and bringing Corona virus to India has also met Du…
RT @RuchiraC: Real leaders are humble, compassionate. They do good because they want to, not for PR. Remembering this &amp; feeling so proud.…
RT @AjayLalluINC: My leader @RahulGandhi ! The true Man.
https://t.co/ZUL1soLBxn
RT @imChandraNew: If Rahul Gandhi is not isolated yet. He must visit his homeland Italy and play political game their.
Thanks @Payal_Rohatg…
@IamPoojaJohari @mujhe to rahul gandhi dikhe
RT @srinivasiyc: 'मुश्किल समय में राहुल गांधी ने मेरे परिवार का हमेशा भावनात्मक और वित्तीय रूप से सहयोग किया लेकिन इस बात को कभी सार्वजनिक…
RT @TinaRoy92936164: @tehseenp @narendramodi हमे तो राहुल गांधी पर भी शक है, हो ना हो जब से वो छुट्टियां बिताकर भारत लौटा , कोराना शुरू तभी…
RT @Supriya23bh: #Nirbhaya “@RahulGandhi looked after us emotionally, monetarily, but asked us to keep it a secret,' says Nirbhaya's father…
etner leader name:Narendra Modhi
-----------tweet for Narendra Modhi ------------
@RakshaRamaiah @iamshivpatil u understand that NARENDRA MODHI is not the name its the BRAND... BRAND.... 😎😎😎😎😎😎😎😎😎😎
RT @VishnumoorthiS1: @PMOIndia @narendramodi Namaste Narendra Modhi ji. Vishnumoorthi Shenoy from Spain we all like your Sistems about our…
@PMOIndia @narendramodi Namaste Narendra Modhi ji. Vishnumoorthi Shenoy from Spain we all like your Sistems about o… https://t.co/UnH4Bk6hbC
@Anilkumarkichh2 @Jawahar50136569 @KicchaNaArmyDvg @BsbTeamOfficial Hiii freinds How are you all
How is my government 💥🙂
Log boltei hai Baaton sei kuch nahi hota kaam bhi karna padta hai, agar yei sach hota to Narendra Modhi Prime Minister nahi hota😂😂.
@narendra_modhi @NikhilMn_04 @KicchaSudeep @anupsbhandari @BosTeamOfficial Lo @BosTeamOfficial avaru keliro ಒಂದೇ ಒಂ… https://t.co/UT5XTSlE3k
@narendra_modhi @NikhilMn_04 @KicchaSudeep @anupsbhandari @BosTeamOfficial @narendra_modhi  guru hogi #coronavirus… https://t.co/V37HGKJeiU
@narendra_modhi @NikhilMn_04 @KicchaSudeep @anupsbhandari @BosTeamOfficial Naan BOS grp allidini Adu hard wrk mado… https://t.co/EaClcroekO
@narendra_modhi @NikhilMn_04 @KicchaSudeep @anupsbhandari @BosTeamOfficial Nod guru Ella FC kelode Anna follow back… https://t.co/nxHojxB1Wv
@narendra_modhi @NikhilMn_04 @KicchaSudeep @anupsbhandari @BosTeamOfficial https://t.co/crY3IalPW3
etner leader name:Aamir Khan
-----------tweet for Aamir Khan ------------
RT @Anjalisaini4325: #GodMorningFriday
लेदर से बनी चीजों का भूलकर भी प्रयोग न करें। इसके लिए जानवरों के साथ बेहद क्रूरता की जाती है। ये एक…
RT @Sushma29497302: #GodMorningFriday

क्या आप को पता है
अब वो दिन दूर नहीं जब संत रामपाल जी महाराज जी पूरे विश्व में अपना नियम लागू करेंगे…
RT @dassi_pinki: #GodMorningFriday
लेदर से बनी चीजों का भूलकर भी प्रयोग न करें। इसके लिए जानवरों के साथ बेहद क्रूरता की जाती है। ये एक महा…
RT @SukhlalDas2: #GodMorningFriday
लेदर से बनी चीजों का भूलकर भी प्रयोग न करें। इसके लिए जानवरों के साथ बेहद क्रूरता की जाती है। ये एक महा…
RT @Aarzoo29220400: #GodMorningFriday
लेदर से बनी चीजों का भूलकर भी प्रयोग न करें। इसके लिए जानवरों के साथ बेहद क्रूरता की जाती है। ये एक म…
RT @Satbir_Akera: #GodMorningWednesday

लेदर से बनी चीजों का भूलकर भी प्रयोग न करें। इसके लिए जानवरों के साथ बेहद क्रूरता की जाती है। ये एक…
RT @SukhlalVishwak4: #GodMorningThursday
लेदर से बनी चीजों का भूलकर भी प्रयोग न करें। इसके लिए जानवरों के साथ बेहद क्रूरता की जाती है। ये ए…
RT @Kulwantdangi0: #GodMorningWednesday

लेदर से बनी चीजों का भूलकर भी प्रयोग न करें। इसके लिए जानवरों के साथ बेहद क्रूरता की जाती है। ये ए…
RT @drivingkingsalm: only actor to give less than 1 lacs Footfalls

1. Salman Khan in 2007
2. Aamir khan in 1984 and 90s

source BOI
RT @MSingh10557694: #FridayThoughts

लेदर से बनी चीजों का भूलकर भी प्रयोग न करें। इसके लिए जानवरों के साथ बेहद क्रूरता की जाती है। ये एक म…
>>> 
= RESTART: C:/Users/vkumar15/AppData/Local/Programs/Python/Python37/TweetExample.py
etner leader name:Narendra Modhi
-----------tweet for Narendra Modhi ------------
u understand that NARENDRA MODHI is not the name its the BRAND.. BRAND... 😎😎😎😎😎😎😎😎😎😎
RT Namaste Narendra Modhi ji Vishnumoorthi Shenoy from Spain we all like your Sistems about our…
Namaste Narendra Modhi ji Vishnumoorthi Shenoy from Spain we all like your Sistems about o
Hiii freinds How are you all How is my government 💥🙂
Log boltei hai Baaton sei kuch nahi hota kaam bhi karna padta hai agar yei sach hota to Narendra Modhi Prime Minister nahi hota😂😂.
_modhi _04 Lo avaru keliro ಒಂದ ಒಂ
_modhi _04 _modhi guru hogi #coronavirus
_modhi _04 Naan BOS grp allidini Adu hard wrk mado
_modhi _04 Nod guru Ella FC kelode Anna follow back
_modhi _04
etner leader name:Rahul Gandhi
-----------tweet for Rahul Gandhi ------------
Jai Congress Jai Rahul Gandhi
RT Ending the day with this article "Nirbhaya's Brother Now A Pilot Parents Say Rahul Gandhi Made It Happen" I am still…
Rahul Gandhi will hold a rally on the Sunday??
RT BJP MP who has commented on Sonia Gandhi and Rahul Gandhi being from Italy and bringing Corona virus to India has also met Du…
Next he will says modiji hi corona ko india me laaye.. Rahul Gandhi bahut duaaon se mila hai India k
RT A story that shows the humanity in a person that’s beyond politics looked after us emotionally monetari…
Kasam se bhare pde hn ek se ek.Rahul Gandhi ne muh par jhada tha us din lekin sharam bech di hai kasam se @_pallavighosh aapne.
RT A story that shows the humanity in a person that’s beyond politics looked after us emotionally monetari…
RT Ending the day with this article "Nirbhaya's Brother Now A Pilot Parents Say Rahul Gandhi Made It Happen" I am still…
RT #Nirbhaya “ looked after us emotionally monetarily but asked us to keep it a secret, says Nirbhaya's father…
etner leader name:Sonia Gandhi
-----------tweet for Sonia Gandhi ------------
RT BJP MP who has commented on Sonia Gandhi and Rahul Gandhi being from Italy and bringing Corona virus to India has also met Du…
RT I remember when was woken up in the wee hours of the night in August 1999 and told that she was to fight…
RT BJP MP who has commented on Sonia Gandhi and Rahul Gandhi being from Italy and bringing Corona virus to India has also met Du…
RT BJP MP who has commented on Sonia Gandhi and Rahul Gandhi being from Italy and bringing Corona virus to India has also met Du…
From sonia gandhi of Congress to late karunanidhi of dmk they possess scam money worth 60 lac crore ...
RT BJP MP who has commented on Sonia Gandhi and Rahul Gandhi being from Italy and bringing Corona virus to India has also met Du…
is party mai koi congress ka bada neta gaye hote bjp ki jagah to godi media ab tak na jane kitne debet chala chuki
Your hindi is better than Sonia Gandhi 😂🤣
How about changing the name of Shaheen Bagh to Jahil Bagh This is for the first time in the history of mankind th
RT Oscar Fernandes a close aid of Sonia Gandhi &amp MP speaks in Rajya Sabha about drinking cow urine &amp practicing Yoga…
>>> 
= RESTART: C:/Users/vkumar15/AppData/Local/Programs/Python/Python37/TweetExample.py
etner leader name:Narendra Modi
-----------tweet for Narendra Modi ------------
Traceback (most recent call last):
  File "C:/Users/vkumar15/AppData/Local/Programs/Python/Python37/TweetExample.py", line 56, in <module>
    get_tweet(name)
  File "C:/Users/vkumar15/AppData/Local/Programs/Python/Python37/TweetExample.py", line 47, in get_tweet
    res = get_sentiment(t)
  File "C:/Users/vkumar15/AppData/Local/Programs/Python/Python37/TweetExample.py", line 31, in get_sentiment
    if analysis.polarity.sentiment>0: #positivive
AttributeError: 'float' object has no attribute 'sentiment'
>>> 
= RESTART: C:/Users/vkumar15/AppData/Local/Programs/Python/Python37/TweetExample.py
etner leader name:Narendra Modhi
-----------tweet for Narendra Modhi ------------
Neutral
Neutral
Neutral
Neutral
Neutral
Neutral
Negative
Neutral
Neutral
Neutral
etner leader name:Rahul Gandhi
-----------tweet for Rahul Gandhi ------------
Neutral
Neutral
Neutral
Positive
Positive
Negative
Negative
Neutral
Neutral
Neutral
etner leader name:Narendra Modi
-----------tweet for Narendra Modi ------------
Neutral
Neutral
Neutral
Neutral
Neutral
Neutral
Neutral
Positive
>>> 
= RESTART: C:/Users/vkumar15/AppData/Local/Programs/Python/Python37/TweetExample.py
etner leader name:Narendra Modi
-----------tweet for Narendra Modi ------------
['Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral']
etner leader name:Rahul Gandhi
-----------tweet for Rahul Gandhi ------------
['Neutral', 'Neutral', 'Negative', 'Positive', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Positive', 'Positive']
etner leader name:Aamir Khan
-----------tweet for Aamir Khan ------------
['Neutral', 'Negative', 'Neutral', 'Neutral', 'Negative', 'Neutral', 'Neutral']
>>> 
= RESTART: C:/Users/vkumar15/AppData/Local/Programs/Python/Python37/TweetExample.py
etner leader name:Rahul Gandhi
-----------tweet for Rahul Gandhi ------------
['Neutral', 'Neutral', 'Positive', 'Negative', 'Positive', 'Neutral', 'Neutral', 'Positive', 'Negative', 'Neutral']
positive = 0.0 negative = 0.0 neutal = 0.0
etner leader name:
= RESTART: C:/Users/vkumar15/AppData/Local/Programs/Python/Python37/TweetExample.py
etner leader name:Rahul Gandhi
-----------tweet for Rahul Gandhi ------------
['Negative', 'Neutral', 'Negative', 'Neutral', 'Neutral', 'Positive', 'Negative', 'Positive', 'Neutral', 'Neutral']
positive = 20.0 negative = 30.0 neutal = 50.0
etner leader name:Sonia Gandhi
-----------tweet for Sonia Gandhi ------------
['Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Positive']
positive = 10.0 negative = 0.0 neutal = 90.0
etner leader name:Narenda Modi
-----------tweet for Narenda Modi ------------
['Neutral', 'Negative', 'Positive', 'Negative', 'Negative', 'Negative', 'Neutral', 'Neutral', 'Neutral', 'Neutral']
positive = 10.0 negative = 40.0 neutal = 50.0
>>> 
= RESTART: C:/Users/vkumar15/AppData/Local/Programs/Python/Python37/TweetExample.py
etner leader name:Rahul Gandhi
-----------tweet for Rahul Gandhi ------------
Status(_api=<tweepy.api.API object at 0x00000232AA2B4248>, _json={'created_at': 'Sat Mar 21 05:29:02 +0000 2020', 'id': 1241235349155635206, 'id_str': '1241235349155635206', 'text': '@SanjayUkroond @narendramodi @PMBhutan Rahul Gandhi ke poore kahandan #Italy me bhoot log ko #covid 19 positive paa… https://t.co/yV4xp6pzst', 'truncated': True, 'entities': {'hashtags': [{'text': 'Italy', 'indices': [70, 76]}, {'text': 'covid', 'indices': [93, 99]}], 'symbols': [], 'user_mentions': [{'screen_name': 'SanjayUkroond', 'name': 'Sanjay Meena', 'id': 191761187, 'id_str': '191761187', 'indices': [0, 14]}, {'screen_name': 'narendramodi', 'name': 'Narendra Modi', 'id': 18839785, 'id_str': '18839785', 'indices': [15, 28]}, {'screen_name': 'PMBhutan', 'name': 'PM Bhutan', 'id': 2902507831, 'id_str': '2902507831', 'indices': [29, 38]}], 'urls': [{'url': 'https://t.co/yV4xp6pzst', 'expanded_url': 'https://twitter.com/i/web/status/1241235349155635206', 'display_url': 'twitter.com/i/web/status/1…', 'indices': [117, 140]}]}, 'metadata': {'iso_language_code': 'hi', 'result_type': 'recent'}, 'source': '<a href="http://twitter.com/download/android" rel="nofollow">Twitter for Android</a>', 'in_reply_to_status_id': 1241060388482891777, 'in_reply_to_status_id_str': '1241060388482891777', 'in_reply_to_user_id': 191761187, 'in_reply_to_user_id_str': '191761187', 'in_reply_to_screen_name': 'SanjayUkroond', 'user': {'id': 1018419245074472962, 'id_str': '1018419245074472962', 'name': 'Saurav Lohani', 'screen_name': 'lohani_saurav', 'location': '', 'description': '', 'url': None, 'entities': {'description': {'urls': []}}, 'protected': False, 'followers_count': 16, 'friends_count': 28, 'listed_count': 0, 'created_at': 'Sun Jul 15 08:57:24 +0000 2018', 'favourites_count': 63, 'utc_offset': None, 'time_zone': None, 'geo_enabled': False, 'verified': False, 'statuses_count': 53, 'lang': None, 'contributors_enabled': False, 'is_translator': False, 'is_translation_enabled': False, 'profile_background_color': 'F5F8FA', 'profile_background_image_url': None, 'profile_background_image_url_https': None, 'profile_background_tile': False, 'profile_image_url': 'http://pbs.twimg.com/profile_images/1018421541963366400/BAyFHHG__normal.jpg', 'profile_image_url_https': 'https://pbs.twimg.com/profile_images/1018421541963366400/BAyFHHG__normal.jpg', 'profile_banner_url': 'https://pbs.twimg.com/profile_banners/1018419245074472962/1531645876', 'profile_link_color': '1DA1F2', 'profile_sidebar_border_color': 'C0DEED', 'profile_sidebar_fill_color': 'DDEEF6', 'profile_text_color': '333333', 'profile_use_background_image': True, 'has_extended_profile': False, 'default_profile': True, 'default_profile_image': False, 'following': False, 'follow_request_sent': False, 'notifications': False, 'translator_type': 'none'}, 'geo': None, 'coordinates': None, 'place': None, 'contributors': None, 'is_quote_status': False, 'retweet_count': 0, 'favorite_count': 0, 'favorited': False, 'retweeted': False, 'lang': 'hi'}, created_at=datetime.datetime(2020, 3, 21, 5, 29, 2), id=1241235349155635206, id_str='1241235349155635206', text='@SanjayUkroond @narendramodi @PMBhutan Rahul Gandhi ke poore kahandan #Italy me bhoot log ko #covid 19 positive paa… https://t.co/yV4xp6pzst', truncated=True, entities={'hashtags': [{'text': 'Italy', 'indices': [70, 76]}, {'text': 'covid', 'indices': [93, 99]}], 'symbols': [], 'user_mentions': [{'screen_name': 'SanjayUkroond', 'name': 'Sanjay Meena', 'id': 191761187, 'id_str': '191761187', 'indices': [0, 14]}, {'screen_name': 'narendramodi', 'name': 'Narendra Modi', 'id': 18839785, 'id_str': '18839785', 'indices': [15, 28]}, {'screen_name': 'PMBhutan', 'name': 'PM Bhutan', 'id': 2902507831, 'id_str': '2902507831', 'indices': [29, 38]}], 'urls': [{'url': 'https://t.co/yV4xp6pzst', 'expanded_url': 'https://twitter.com/i/web/status/1241235349155635206', 'display_url': 'twitter.com/i/web/status/1…', 'indices': [117, 140]}]}, metadata={'iso_language_code': 'hi', 'result_type': 'recent'}, source='Twitter for Android', source_url='http://twitter.com/download/android', in_reply_to_status_id=1241060388482891777, in_reply_to_status_id_str='1241060388482891777', in_reply_to_user_id=191761187, in_reply_to_user_id_str='191761187', in_reply_to_screen_name='SanjayUkroond', author=User(_api=<tweepy.api.API object at 0x00000232AA2B4248>, _json={'id': 1018419245074472962, 'id_str': '1018419245074472962', 'name': 'Saurav Lohani', 'screen_name': 'lohani_saurav', 'location': '', 'description': '', 'url': None, 'entities': {'description': {'urls': []}}, 'protected': False, 'followers_count': 16, 'friends_count': 28, 'listed_count': 0, 'created_at': 'Sun Jul 15 08:57:24 +0000 2018', 'favourites_count': 63, 'utc_offset': None, 'time_zone': None, 'geo_enabled': False, 'verified': False, 'statuses_count': 53, 'lang': None, 'contributors_enabled': False, 'is_translator': False, 'is_translation_enabled': False, 'profile_background_color': 'F5F8FA', 'profile_background_image_url': None, 'profile_background_image_url_https': None, 'profile_background_tile': False, 'profile_image_url': 'http://pbs.twimg.com/profile_images/1018421541963366400/BAyFHHG__normal.jpg', 'profile_image_url_https': 'https://pbs.twimg.com/profile_images/1018421541963366400/BAyFHHG__normal.jpg', 'profile_banner_url': 'https://pbs.twimg.com/profile_banners/1018419245074472962/1531645876', 'profile_link_color': '1DA1F2', 'profile_sidebar_border_color': 'C0DEED', 'profile_sidebar_fill_color': 'DDEEF6', 'profile_text_color': '333333', 'profile_use_background_image': True, 'has_extended_profile': False, 'default_profile': True, 'default_profile_image': False, 'following': False, 'follow_request_sent': False, 'notifications': False, 'translator_type': 'none'}, id=1018419245074472962, id_str='1018419245074472962', name='Saurav Lohani', screen_name='lohani_saurav', location='', description='', url=None, entities={'description': {'urls': []}}, protected=False, followers_count=16, friends_count=28, listed_count=0, created_at=datetime.datetime(2018, 7, 15, 8, 57, 24), favourites_count=63, utc_offset=None, time_zone=None, geo_enabled=False, verified=False, statuses_count=53, lang=None, contributors_enabled=False, is_translator=False, is_translation_enabled=False, profile_background_color='F5F8FA', profile_background_image_url=None, profile_background_image_url_https=None, profile_background_tile=False, profile_image_url='http://pbs.twimg.com/profile_images/1018421541963366400/BAyFHHG__normal.jpg', profile_image_url_https='https://pbs.twimg.com/profile_images/1018421541963366400/BAyFHHG__normal.jpg', profile_banner_url='https://pbs.twimg.com/profile_banners/1018419245074472962/1531645876', profile_link_color='1DA1F2', profile_sidebar_border_color='C0DEED', profile_sidebar_fill_color='DDEEF6', profile_text_color='333333', profile_use_background_image=True, has_extended_profile=False, default_profile=True, default_profile_image=False, following=False, follow_request_sent=False, notifications=False, translator_type='none'), user=User(_api=<tweepy.api.API object at 0x00000232AA2B4248>, _json={'id': 1018419245074472962, 'id_str': '1018419245074472962', 'name': 'Saurav Lohani', 'screen_name': 'lohani_saurav', 'location': '', 'description': '', 'url': None, 'entities': {'description': {'urls': []}}, 'protected': False, 'followers_count': 16, 'friends_count': 28, 'listed_count': 0, 'created_at': 'Sun Jul 15 08:57:24 +0000 2018', 'favourites_count': 63, 'utc_offset': None, 'time_zone': None, 'geo_enabled': False, 'verified': False, 'statuses_count': 53, 'lang': None, 'contributors_enabled': False, 'is_translator': False, 'is_translation_enabled': False, 'profile_background_color': 'F5F8FA', 'profile_background_image_url': None, 'profile_background_image_url_https': None, 'profile_background_tile': False, 'profile_image_url': 'http://pbs.twimg.com/profile_images/1018421541963366400/BAyFHHG__normal.jpg', 'profile_image_url_https': 'https://pbs.twimg.com/profile_images/1018421541963366400/BAyFHHG__normal.jpg', 'profile_banner_url': 'https://pbs.twimg.com/profile_banners/1018419245074472962/1531645876', 'profile_link_color': '1DA1F2', 'profile_sidebar_border_color': 'C0DEED', 'profile_sidebar_fill_color': 'DDEEF6', 'profile_text_color': '333333', 'profile_use_background_image': True, 'has_extended_profile': False, 'default_profile': True, 'default_profile_image': False, 'following': False, 'follow_request_sent': False, 'notifications': False, 'translator_type': 'none'}, id=1018419245074472962, id_str='1018419245074472962', name='Saurav Lohani', screen_name='lohani_saurav', location='', description='', url=None, entities={'description': {'urls': []}}, protected=False, followers_count=16, friends_count=28, listed_count=0, created_at=datetime.datetime(2018, 7, 15, 8, 57, 24), favourites_count=63, utc_offset=None, time_zone=None, geo_enabled=False, verified=False, statuses_count=53, lang=None, contributors_enabled=False, is_translator=False, is_translation_enabled=False, profile_background_color='F5F8FA', profile_background_image_url=None, profile_background_image_url_https=None, profile_background_tile=False, profile_image_url='http://pbs.twimg.com/profile_images/1018421541963366400/BAyFHHG__normal.jpg', profile_image_url_https='https://pbs.twimg.com/profile_images/1018421541963366400/BAyFHHG__normal.jpg', profile_banner_url='https://pbs.twimg.com/profile_banners/1018419245074472962/1531645876', profile_link_color='1DA1F2', profile_sidebar_border_color='C0DEED', profile_sidebar_fill_color='DDEEF6', profile_text_color='333333', profile_use_background_image=True, has_extended_profile=False, default_profile=True, default_profile_image=False, following=False, follow_request_sent=False, notifications=False, translator_type='none'), geo=None, coordinates=None, place=None, contributors=None, is_quote_status=False, retweet_count=0, favorite_count=0, favorited=False, retweeted=False, lang='hi')
[]
Traceback (most recent call last):
  File "C:/Users/vkumar15/AppData/Local/Programs/Python/Python37/TweetExample.py", line 80, in <module>
    p = (len(pos)/len(res))*100
ZeroDivisionError: division by zero
>>> 
= RESTART: C:/Users/vkumar15/AppData/Local/Programs/Python/Python37/TweetExample.py
etner leader name:Narendra Modi
-----------tweet for Narendra Modi ------------
['Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Neutral', 'Positive', 'Neutral']
positive = 10.0 negative = 0.0 neutal = 90.0
etner leader name:Rahul Gandhi
-----------tweet for Rahul Gandhi ------------
['Neutral', 'Positive', 'Neutral', 'Positive', 'Positive', 'Neutral', 'Neutral', 'Negative', 'Neutral', 'Neutral']
positive = 30.0 negative = 10.0 neutal = 60.0
>>> 