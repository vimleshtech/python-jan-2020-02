#function with argument and default value 
def add(a,b=0,c=0,d=0):
    c =a+b
    print(c)
    return c

#function with dynamic count of arguments
def mul(*arg): #argument type is tuple
    #print(type(arg))
    #print(arg)
    m =1
    for x in arg:
        #print(x)
        m*=x

    print(m)
          

##lambda
tax = lambda amt : amt*.18

b = lambda a,b : a== b

'''
def tax(amt):
    amt = amt*.18
    return amt 
'''

#recussion
def fact(n):
    if n==1:
        return n
    else:
        return n*fact(n-1)  # 5 * 4 * 3 * 2 *1

    

add(11)
add(11,4,445)
add(11,4,445,4)


mul(11,43,5,66,7,4,35,76,4,3,6,7)
mul(11,43,5,66,7,4,35,76,4,3,6,7,5,67,346)

print(tax(1000))


f = fact(15)
print(f)



