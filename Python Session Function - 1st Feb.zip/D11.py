
a= [11,3,3,5,-5,6,4,-6,-8,3]

b = a.copy()

si =0 
eid = len(a)-1

for x in a:
    if x<0:
        b[si]= x
        si+=1
    else:
        b[eid] = x
        eid -=1

print(a)
print(b)


