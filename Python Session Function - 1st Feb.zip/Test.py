y =[]
def  solve(data):

    if type(data) not in (list,tuple,dict,set):
        #print(data)
        y.append(data)
    else:
        for x in data:
            solve(x)
            
            


a = [111,343,5,[44,665,7,[55,667,66]],55,77,8,[44,66,7,8,777,[55,67,[55,77]]]]
solve(a)
print(y)

#out     
#    =[111,343,5,,44,665,7,55,667,66,55,77,8,44,66,7,8,777,55,67,55,77]
     
     

##comperhensive list  []
d =[11,3,4,6,7,4,4,6767]

print([x*2 for x in d])

for x in d:
    print(x*2)
    



     

