#delare the function

#no argument no return 
def welcome():
    print('this is test function , there are add, getinput, sub , mul funciton in this program' )


#no argument with return
def getNum():
    a = int(input('enter data :'))
    b = int(input('enter data :'))
    return a,b
    

#argument with no return
def add(a,b):
    c =a+b
    print(c)

#argument with return
def sub(a,b):
    c =a-b
    return c


#call or invoke the function
welcome()

x,y = getNum()
add(x,y)
add(111,44)
add(155,446)

o = sub(x,y)
print(o)

add(o,100)

a,b = getNum()
print(a-b)

    

