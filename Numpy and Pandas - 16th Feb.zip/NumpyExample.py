import numpy as np

#generate the range 
x = np.arange(10) #0 to 9
print(x)


x = np.arange(2,10) #2 to 9
print(x)


x = np.arange(2,10,.1) #2 to 9
print(x)


##array : convert list to array
l =[111,2,3,45,66,333]
y = np.array(l)

print(l)
print(l*3)
print(type(l))

print(y)
print(y*3)
print(type(y))


#
a =[1,2,3,4,5,6,7,8,9]

'''
1 4 7
2 5 8
3 6 9
'''

x = np.array(a).reshape(-1,3)
print(x)
print(x*3)


#or
#a =[1,2,3,4,5,6,7,8,9]
#y = np.array(a)
#z= y.reshape(1,3)

y = np.array(a).reshape(-1,1)
print(y)

print(x.shape)
print(y.shape)



###
x = np.ones(10)
print(x)

x = np.zeros(10)
print(x)


###
a = [[1,2,3],[1,2,3],[1,2,3]]
b = [[11,22,3],[1,27,3],[10,2,30]]

a = np.array(a)
b = np.array(b)
print(a)
print(b)

print(np.subtract(a,b))
print(np.add(a,b))
print(np.multiply(a,b))






























