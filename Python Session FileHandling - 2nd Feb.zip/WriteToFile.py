#C:\Users\vkumar15\Desktop\


#a= open('test.txt','w') #create new file at default location , w -create/overwrite
a= open(r'C:\Users\vkumar15\Desktop\test.txt','a')#open the file in append mode


a.write('hello \n')
a.write('thank you \n')
a.close()

print('data is saved in given file  ')






