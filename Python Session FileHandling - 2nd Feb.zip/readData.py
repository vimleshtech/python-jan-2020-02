x= open(r'C:\Users\vkumar15\Desktop\test.txt','r')


#print(x.read())

#print(x.readline())

#print(x.readlines())
r =x.readlines()
print(len(r))

print(r[1])


for row in r:
    print(row)
    



x.close()

