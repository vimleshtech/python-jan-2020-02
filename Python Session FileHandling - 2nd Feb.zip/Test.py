def get_ascii(s):

    a= [] #empty list 
    for c in s:
        #print(ord(c))
        a.append(ord(c))

    return a


#call to function
s = input('enter string :')
o = get_ascii(s)
print(o)



        
