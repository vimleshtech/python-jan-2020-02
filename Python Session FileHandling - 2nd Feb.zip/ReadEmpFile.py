f = open(r'C:\Users\vkumar15\Desktop\emp.txt','r')

f.readline()

data= f.readlines()
#print(data)
f.close()
fc = 0
mc = 0

s = 0
#get male and female count, and %
for r in data:
    col = r.split(',')
    s = s+int(col[3])
    
    #print(col)
    if col[2] =='male':
        mc+=1

    elif col[2]=='female':
        fc+=1      
        
    
    #print(r)
print('total sal ',s)
print('male count ', mc)
print('female count ', fc)
print('male count ', mc/(mc+fc))
print('male count ', fc/(mc+fc))

