import os

o = os.listdir(r'C:\Users\vkumar15\AppData\Local\Programs\Python\Python37-32')
print(o)

print(len(o))

for f in o:
    if f.endswith('txt'):
        print(f)
        fi= open(f)
        print(fi.read())
        
        


