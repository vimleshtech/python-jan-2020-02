#declare the list 
x = []

i =11
while i<=20:
    n = int(input('enter num :'))
    x.append(n)

    i =i+1

print(x)

    
##get count of pos and neg values
pos =0
neg =0

i =0
while i<10:
    if x[i] <0:
        neg +=1
    else:
        pos +=1


    i +=1

print('pos count ', pos)
print('neg count ', neg)

    


