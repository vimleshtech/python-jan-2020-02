
s = input('enter string :')


w = s.split(" ")
ns = input('enw string to search :')

i =0
while i<len(w):
    if w[i] ==ns:
        print(ns,' is match at ',i)
        
