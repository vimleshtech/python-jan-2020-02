#for loop : print series from 1 to 10
for x in range(1,11):
    print(x)
    

#print in single line
for x in range(1,11):
    print(x,end='') #end is keyword which remove \n (new line)
    

#print in reverse
for x in range(10,0,-1):
    print(x)
    


#advantage of for over while
a = [11,33,45,56,3,5565]
for d in a:
    print(d)
    

##string
s ='fkhdfdgydfdtd ffgf'
for c in s:
    print(c)
    
