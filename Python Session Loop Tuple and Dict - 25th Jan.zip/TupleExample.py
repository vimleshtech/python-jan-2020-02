data = (11,33,5,5,33,555)

print(max(data))
print(min(data))
print(sum(data))
print(len(data))
print(data)

print(data.count(5))

print(data[0])

print(data[1:4])


##error
#data.sort()
#data[0] =4



