s = input('enter string :')

#c = list(s)

uc =0
lc = 0
i =0
while i<len(s):

    if s[i].isupper():
        uc+=1
        

    elif s[i].islower():
        lc+=1
    
    i+=1

print('upper case ',uc)
print('lower case ',lc)

    
