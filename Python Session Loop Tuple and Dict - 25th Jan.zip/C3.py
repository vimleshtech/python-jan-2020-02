s = input('etner string :')

print(len(s)) #total len 

print(s.replace(" ","")) #emove the space

print(len(s.replace(" ",""))) #get the len after remove the space






