#break

for x in range(1,10):
    if x%3 ==0:
        break
    
    print(x)

#continue    
for x in range(1,10):
    if x%3 ==0:
        continue
    
    print(x)


#1 2 4 5 7 8 
