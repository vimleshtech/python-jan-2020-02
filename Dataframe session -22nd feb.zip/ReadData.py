import pandas as pd



##save data to file
emp = pd.read_csv(r'D:\Python 3.8\Numpy and Pandas - 16th Feb\mycardata.csv')

#pip instal xlrd
#pd.read_excel(r'D:\Python 3.8\Numpy and Pandas - 16th Feb\emp1.csv',sheet_name='sheet1')


print(emp)


#
print(emp.info())

print(emp.describe())


##
print(emp.corr())


o = emp.corr()

o.to_csv(r'D:\Python 3.8\Numpy and Pandas - 16th Feb\corr.csv')




