
import pandas as pd


#create empty data frame
df = pd.DataFrame()
print(df)


#create data from dict
d = {'eid':[1,2,3,4,5,6,7],'name':['a','b','c','d','a','a','c']}

print(d)
df = pd.DataFrame(data=d)
print(df)


#print index
print(df.index)
print(df.columns)

#extract data from dataframe
print(df['name'])
print(df[['name','eid','name']])


#show top given rows
print(df.head(n=2))

#from buttom
print(df.tail(n=2))


#add new col in existing dataframe
g = ['m','m','f','m','f','f','m']

df['gender'] = g
print(df)



s = [666,666,777,666,677,66,66]

df['sal'] = s
print(df)


print(df)


##
data = df.values
print(data)


print(data[:,0:3])

print(data[1:5,0:3])


sal = data[:,3]
print(sal)

ysal = sal*12
print(ysal)

df['ysal'] = ysal
print(df)

##save data to file
df.to_csv(r'D:\Python 3.8\Numpy and Pandas - 16th Feb\emp1.csv',index=False)
























