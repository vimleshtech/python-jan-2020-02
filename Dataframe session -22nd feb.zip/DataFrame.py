import pandas as pd


#create empty dataframe
df = pd.DataFrame()
print(df)


##create dict to dataframe
emp = {'eid':[1,2,3,4,5,6,7,8,9,10] ,
       'name':['a','b','c','d','e','f','aa','bb','nitin','monika'] ,
       'gender':['f','f','f','m','m','f','f','f','m','f'] ,
       'salary':[10000,20000,30000,40000,50000,60000,70000,80000,900000,110000] }

print(emp)

employee = pd.DataFrame(data=emp)
print(employee)

##
print(employee.columns)
print(employee.index)

#print selected cols
print(employee['name'])
print(employee[['name','gender']])
print(employee[['name','gender','salary']])


#show info
print(employee.info())


##
print(employee.head(n=3)) #return from top , default count is 5
print(employee.tail(n=3)) #retun from buttom, default count is 5


###show stats : max, min, sum, mean , 25%, 50 % , 75%
print(employee.describe())


##group by / data distribuation
print(employee.groupby('gender').size())


#order by : sorting
print(employee.sort_values('salary',ascending=False))


#conditon / where
x= employee[employee['gender']=='f']
print(x)
print(x.groupby('gender').size())

print(employee[employee['gender']=='f'].groupby('gender').size())

#
x.to_csv('out.csv')






























