d = []
i =0

while i<=10:
    a = int(input('enter data :'))
    d.append(a)

    i =i+1

print(d)

m = max(d) #highest value

i =0
loc = -1
while i<=10:
    if d[i] == m:
        loc = i        

    i =i+1

print('location of max value is ',loc)


    
##

d.remove(m)
m = max(d)

i =0
loc = -1
while i<=10:
    if d[i] == m:
        loc = i        

    i =i+1

print('location of 2nd max value is ',loc, m )






