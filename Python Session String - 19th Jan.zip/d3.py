a = []
b = []


#fill data in a 
i =0
while i<5:
    d = int(input('enter data 1 '))    
    a.append(d)    
    i =i+1

#fill data in b 
i =0
while i<5:
    d = int(input('enter data  2'))
    b.append(d)    
    i =i+1

#sub
i =0
while i<5:
    print(a[i] - b[i])
    i =i+1
    


