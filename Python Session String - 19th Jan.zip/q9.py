a =[]
i = 0
while i<10:
    d = int(input('enter data :'))
    a.append(d)
    i=i+1

print(a)

n = int(input('enter position :'))


b = a[0:n]

a[0:n] =[]

a.extend(b)
print(a)


##
i = 0
nc = 0
pc =0
while i<10:
    d = int(input('enter data :'))
    if d[i]<0:
        nc =nc+1
    else:
        pc =pc+1
        
    i=i+1
