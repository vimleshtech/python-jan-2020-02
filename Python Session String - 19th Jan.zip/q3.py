n = int(input('enter data :'))

n = n*n
print(n)

