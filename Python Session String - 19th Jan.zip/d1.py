
sales = []
i =1
while i<=10:

    d = input('enter data ')    
    sales.append(d)
    
    i =i+1
    
print(sales)
