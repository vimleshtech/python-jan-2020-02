
s  = input('etner string :')

print(s.upper())
print(s.lower())
print(s.title())
print(s.capitalize())
print(s.swapcase())


print(len(s))
print(s.count('i'))


l = list(s)
print(l)



words = s.split(' ')
print(words)


o = ord(s[0]) # 65 - 91 , 97 - 123
print(o)

print(chr(48))

print(s[0:4])

'''
A = 65
65/2 = 1
32/2 = 0
16/2 = 0
8/2 = 0
4/2 = 0
2/2 = 0
1


1000001

'''


