
s = input('enter string ')

print(s.count(' '))
print(s.count('\t'))
print(s.count('\n'))

###c5
l =list(s)

'''
0-9: 48 to 57
A-Z: 65 to 91
a-z: 97 to 123

'''
i =0
dc = 0
uc =0
vc =0
cc =0
while i<len(l):
    if ord(l[i]) >= 48 and  ord(l[i]) <57:
        dc =dc+1
    if ord(l[i]) >= 65 and  ord(l[i]) <97:
        uc =uc+1
    if l[i] in ('a','e','i','o','u'):
        vc =vc+1
    else:
        cc=cc+1
        
        
    i =i+1

print(dc)

print(uc)

        
